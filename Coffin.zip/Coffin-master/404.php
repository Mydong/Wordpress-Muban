<?php get_header(); ?>
    <div class="layoutSingleColumn--wide xs-layoutSingleColumn--wide">
        <section class="error-404 not-found">
            404
        </section>
    </div>
<?php get_footer(); ?>