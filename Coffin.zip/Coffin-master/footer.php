<footer class="site-footer">
    <div class="layoutSingleColumn--wide">
        just a <a href="https://fatesinger.com" target="_blank">bigfa</a> wordpress theme.
    </div>
</footer>
<?php wp_footer();?>
</body>
</html>