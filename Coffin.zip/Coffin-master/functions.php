<?php
define('COFFIN_VERSION', '1.0.8');
define('COFFIN_DEBUG', false);

require('inc/setup.php');
require('inc/static.php');
require('inc/base.php');