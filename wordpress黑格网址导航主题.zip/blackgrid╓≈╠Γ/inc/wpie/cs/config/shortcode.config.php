<?php if (!defined('ABSPATH')) {
    die;
}

include get_template_directory().'/inc/config/shortcode.config.php';

