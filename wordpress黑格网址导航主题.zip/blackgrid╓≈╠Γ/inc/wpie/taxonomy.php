<?php
/**
 * 更多资源请关注：三岁半资源网:sansuib.com
 * User: Overbool
 * Date: 2019-04-12
 * Time: 23:17
 */

/**
 * @param $id
 * @return array|int|WP_Error
 */
function wpie_get_child_categories($id)
{
  $taxonomies = array(
    'category',
  );

  $args = array(
    'parent' => $id,
  );
  return get_terms($taxonomies, $args);
}