<?php
/*
Plugin Name: RIPRO下载信息框
Plugin URI: https://saodaye.com
Description: 为RIPRO主题文章增加下载信息框.RIPRO5.4以下自行测试,非ripro主题请勿使用！请勿使用！请勿使用！
Author: wpmes team
Version: 1.2
Author URI:https://saodaye.com
*/
define('RIPRODL_PATH',dirname(__FILE__));
define('RIPRODL_BASE_FILE',__FILE__);
define('RIPRODL_VERSION','1.1');


require_once RIPRODL_PATH.'/front.class.php';




new RIPRODL_DownLoadFront();
add_filter('single_template', 'my_custom_template');

function my_custom_template($single) {

    global $post;

    /* Checks for single template by post type */
   
        if ( file_exists( RIPRODL_PATH. '/riprodl_single.php' ) ) {
            return RIPRODL_PATH. '/riprodl_single.php';
        }
    

    return $single;

}

add_action( 'after_setup_theme', 'opt_ver' );

function opt_ver() {
    $prefix_post_opts = '_cao_single_ver';
    CSF::createMetabox($prefix_post_opts, array(
        'title'     => '资源版本设置',
        'post_type' => 'post',
        'data_type' => 'unserialize',
        'priority'  => 'high',
      
    ));

    CSF::createSection($prefix_post_opts, array(
        'fields' => array(
      
            array(
                'id'         => 'cao_ver',
                'type'       => 'repeater',
                'title'      => '版本设置',
                
                'fields'     => array(
                    array(
                        'id'      => 'title',
                        'type'    => 'text',
                        'title'   => '版本号',
                        'default' => '写上该版本的版本号',
                    ),
                      array(
                        'id'      => 'time',
                        'type'    => 'text',
                        'title'   => '更新时间',
                        'default' => '此版本更新的时间如2020年1月2日',
                    ),
                    array(
                        'id'      => 'desc',
                        'type'    => 'text',
                        'title'   => '更新内容',
                        'default' => '写更新的主要内容',
                    ),
                ),
            ),


        ),
    ));
    //添加代码插入按钮
add_action('admin_init', 'insert_code_button');
function insert_code_button(){
    if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') ) {
            return;
    }
    add_filter( 'mce_external_plugins', 'add_highlight_button_plugin' );
    add_filter( 'mce_buttons', 'register_highlight_button' );
}
function register_highlight_button( $buttons ) {
    array_push( $buttons, "|", "highlight" );
    return $buttons;
}
function add_highlight_button_plugin(){
    $plugin_array['highlight'] = plugin_dir_url(RIPRODL_BASE_FILE) . '/assets/myhtml.js';
    return $plugin_array;
}
}