<?php
/**
 * 选项面板
 *
 * @package WordPress
 * @subpackage Beginning
 *
 * @since Unknown
 * @deprecated Beginning 4.0.5 Use `functions/class-mpanel-panel.php`。
 */

_deprecated_file( basename( __FILE__ ), '4.0.5', 'functions/class-mpanel-panel.php' );
require_once( get_template_directory() . '/functions/class-mpanel-panel.php' );

// End of page.
