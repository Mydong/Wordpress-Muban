<?php
/**
 * 设置选项
 *
 * @package WordPress
 * @subpackage Beginning
 *
 * @since Unknown
 * @deprecated Beginning 4.0.5 Use `functions/class-mpanel.php`。
 */

_deprecated_file( basename( __FILE__ ), '4.0.5', 'functions/class-mpanel.php' );
require_once( get_template_directory() . '/functions/class-mpanel.php' );

// End of page.
